// ==UserScript==
// @name         GMGN AI 叙事 → GIGA X 叙事
// @namespace    https://github.com/whitestar224/market-hot-dashboard
// @version      1.5.7
// @description  把 GMGN 网页端代币 AI 叙事悬浮窗内容替换为 GIGA X 对应代币的叙事分析
// @author       market-hot-dashboard
// @match        *://gmgn.ai/*
// @match        *://www.gmgn.ai/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @grant        unsafeWindow
// @connect      127.0.0.1
// @connect      localhost
// @run-at       document-idle
// @noframes
// ==/UserScript==

(function () {
  'use strict';

  const W = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

  // ===== 配置 =====
  // 桥接已集成进 market-hot-dashboard 主服务（server.py 端口 8765），随主服务一起启动。
  // 桥接根地址：**只填到端口**，路由前缀 /api/gigax 由脚本补。
  const BRIDGE_RAW = GM_getValue('bridge', 'http://127.0.0.1:8765');
  const BRIDGE = BRIDGE_RAW.replace(/\/+$/, '').replace(/\/api\/gigax$/, '');
  const API = BRIDGE + '/api/gigax';

  const POLL_MS = 1500;            // 轮询保底（快路径是 DOM 观察 + hover 预热；放宽以减轻主线程压力）
  const CACHE_TTL = 30 * 60 * 1000;// 同一 CA 叙事缓存 30 分钟（和服务端一致）
  const NO_DATA_TTL = 2 * 60 * 1000;// 「GIGA X 没有这个币」也缓存 2 分钟，别反复打桥接
  const NET_AI_TTL = 30000;        // 叙事类请求的 CA 有效期（30s：再长就会跨币串味——旧请求的币顶掉当前币）
  const NET_ANY_TTL = 8000;        // 任意带 CA 的请求有效期（收紧，避免列表请求串味）

  // 悬浮窗正文的特征锚点（GMGN 固定的免责声明文案）
  const ANCHORS = [
    '人工智能生成内容',
    '免责声明',
    '投资需自行研究',
    'AI 生成',
    'AI生成',
    'AI 分析',
    'AI 总结',
    'AI 叙事',
  ];
  const CONTAINER_HINTS = ['tooltip', 'popover', 'popper', 'tippy', 'floating', 'ai-narrative', 'ai-analysis', 'bubble', 'card-pop'];

  let enabled = GM_getValue('enabled', true);
  // 机会标记：strict=严格（强关键词，或 2 个弱关键词）| loose=任一关键词 | off=关
  let hotMode = GM_getValue('hotMark', 'strict');
  const cache = new Map(); // chain:ca -> {text, ts}

  function log(...a) { console.log('[GMGN→GIGAX]', ...a); }
  function warn(...a) { console.warn('[GMGN→GIGAX]', ...a); }

  // ===== 菜单 =====
  GM_registerMenuCommand(enabled ? '关闭替换' : '开启替换', () => {
    enabled = !enabled;
    GM_setValue('enabled', enabled);
    log('替换已' + (enabled ? '开启' : '关闭'));
    if (!enabled) restoreAll();
  });
  GM_registerMenuCommand('设置桥接地址', () => {
    const v = prompt('GIGA X 桥接根地址（默认 http://127.0.0.1:8765，只填到端口即可）:', BRIDGE);
    if (v) { GM_setValue('bridge', v); location.reload(); }
  });
  GM_registerMenuCommand('打印悬浮窗 DOM（调试）', dumpFloating);
  GM_registerMenuCommand(hotMode === 'off' ? '开启机会标记（蓝底卡片）' : '关闭机会标记（蓝底卡片）', () => {
    hotMode = hotMode === 'off' ? 'strict' : 'off';
    GM_setValue('hotMark', hotMode);
    log('机会标记已' + (hotMode === 'off' ? '关闭' : '开启'));
    paintHotCards(true);
  });
  GM_registerMenuCommand(
    hotMode === 'loose' ? '标记严格度：宽松（任一关键词）→ 切回严格' : '标记严格度：严格 → 切宽松（任一关键词就标）',
    () => {
      hotMode = hotMode === 'loose' ? 'strict' : 'loose';
      GM_setValue('hotMark', hotMode);
      log('标记严格度：' + hotMode);
      paintHotCards(true);
    },
  );

  // ===== 地址解析 =====
  const EVM_RE = /0x[a-fA-F0-9]{40}/;
  const EVM_RE_G = /0x[a-fA-F0-9]{40}/g;
  const CHAINS = ['sol', 'eth', 'bsc', 'base', 'robinhood', 'blast', 'tron', 'arbitrum', 'polygon'];

  const isEvm = ca => /^0x[a-fA-F0-9]{40}$/.test(ca || '');
  // base58 **大小写敏感**：Solana 地址一旦 lower() 就变成另一个地址，
  // 桥接会查到一个不存在的币，静默返回空 —— 这是「Solana 的币全都没有叙事」的元凶。
  const isSol = ca => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(ca || '');
  const normCa = ca => (isEvm(ca) ? ca.toLowerCase() : ca);

  // 从一段 URL 里解析出 {chain, ca}
  // GMGN 的地址页形状是 /<chain>/token/<CA>（链名在前）。老版本只认 /token/<chain>/<CA>，
  // 于是 Solana 页面上的地址一个都解析不出来 —— 「有些币没替换」的另一个主因。
  function parseUrlToken(href) {
    if (!href) return null;
    const s = String(href);
    const withChain = (chain, raw) => {
      const ca = normCa(raw);
      if (!isEvm(ca) && !isSol(ca)) return null;
      const c = CHAINS.includes(String(chain || '').toLowerCase()) ? String(chain).toLowerCase() : null;
      return { chain: c, ca };
    };
    let m = s.match(/\/([a-z]{2,10})\/token\/([0-9a-zA-Z]{32,64})/i);
    if (m) { const r = withChain(m[1], m[2]); if (r) return r; }
    m = s.match(/\/token\/([a-z]{2,10})\/([0-9a-zA-Z]{32,64})/i);
    if (m) { const r = withChain(m[1], m[2]); if (r) return r; }
    m = s.match(/[?&](?:address|token|tokenAddress|ca|contract)=([0-9a-zA-Z]{32,64})/i);
    if (m) { const r = withChain(null, m[1]); if (r) return r; }
    // 只有 CA 没有链名：EVM 直接认，base58 归 sol
    m = s.match(/\/(?:token|address)\/([1-9A-HJ-NP-Za-km-z]{32,44})(?:[?#/]|$)/);
    if (m && isSol(m[1])) return { chain: 'sol', ca: m[1] };
    m = s.match(EVM_RE);
    if (m) return { chain: null, ca: m[0].toLowerCase() };
    return null;
  }

  // ===== 网络嗅探：GMGN 自己请求哪个币的叙事，就用哪个 CA =====
  // 这是最可靠的来源 —— 悬浮窗是按那次请求渲染出来的，DOM 里反而常常没有地址，
  // 老版本在这里兜底用了 location.href，于是「页面主体的币」会顶掉「卡片上的币」。
  const netEvents = [];
  const AI_PATH_RE = /narrative|analysis|ai_|ai-|social|story|insight/;
  // 每来一次「叙事类」请求就 +1。悬浮窗换币时 GMGN 一定会重新请求叙事，
  // 这比「比对 CA」便宜得多，用来作废「已知无数据」的标记（否则换到新币会一直保持原文）。
  let netVersion = 0;
  function noteUrl(url) {
    try {
      const parsed = parseUrlToken(url);
      if (!parsed) return;
      const path = String(url).toLowerCase();
      const isAi = AI_PATH_RE.test(path);
      netEvents.push({ ...parsed, path, isAi, ts: Date.now() });
      if (isAi) {
        netVersion++;
        // 事件驱动：GMGN 发叙事类请求 ≈ 悬浮窗马上要出现。此刻才值得扫一次，
        // 平时完全不扫 —— 这是把「定时轮询压主线程」降到最低的关键。
        scheduleScan(40);
      }
      if (netEvents.length > 60) netEvents.shift();
    } catch (e) { /* ignore */ }
  }
  function installNetSniffer() {
    try {
      const f = W.fetch;
      if (typeof f === 'function' && !f.__gigaxPatched) {
        const patched = function (input, init) {
          try {
            noteUrl(typeof input === 'string' ? input : (input && input.url));
            // 地址也可能在 POST body 里（GraphQL / JSON）
            const b = init && init.body;
            if (typeof b === 'string') noteUrl(b);
          } catch (e) {}
          return f.apply(this, arguments);
        };
        patched.__gigaxPatched = true;
        W.fetch = patched;
        log('fetch 嗅探已挂');
      }
    } catch (e) { warn('fetch 嗅探失败', e); }
    try {
      const X = W.XMLHttpRequest;
      if (X && X.prototype && !X.prototype.__gigaxPatched) {
        const open = X.prototype.open;
        X.prototype.open = function (method, url) {
          try { noteUrl(url); this.__gigaxUrl = String(url); } catch (e) {}
          return open.apply(this, arguments);
        };
        X.prototype.__gigaxPatched = true;
        const send = X.prototype.send;
        X.prototype.send = function (data) {
          try {
            const low = String(this.__gigaxUrl || '');
            if (typeof data === 'string' && /narrative|analysis|ai_|ai-|social|story|insight/.test(low)) {
              noteUrl(data);
            }
          } catch (e) {}
          return send.apply(this, arguments);
        };
        log('XHR 嗅探已挂');
      }
    } catch (e) { warn('XHR 嗅探失败', e); }
  }
  installNetSniffer();

  // ===== DOM 侧兜底 =====
  const lastPointer = { x: 0, y: 0 };
  document.addEventListener('mousemove', e => {
    lastPointer.x = e.clientX;
    lastPointer.y = e.clientY;
  }, { passive: true, capture: true });

  function collectUrlsIn(scope) {
    const found = [];
    const push = (v) => {
      const p = parseUrlToken(v);
      if (p) found.push(p);
    };
    try {
      scope.querySelectorAll('a[href]').forEach(a => push(a.getAttribute('href')));
      for (const el of [scope, ...scope.querySelectorAll('[data-address],[data-ca],[title]')]) {
        if (!el || !el.attributes) continue;
        for (const at of el.attributes) push(at.value || '');
      }
      const text = scope.innerText || '';
      (text.match(EVM_RE_G) || []).forEach(ca => found.push({ chain: null, ca: ca.toLowerCase() }));
    } catch (e) { /* ignore */ }
    return found;
  }

  function uniqueCas(list) {
    const seen = new Set();
    const out = [];
    for (const it of list) {
      if (seen.has(it.ca)) continue;
      seen.add(it.ca);
      out.push(it);
    }
    return out;
  }

  // 从某个元素向上找它所属的「代币卡片」
  function caFromElement(el) {
    let cur = el;
    for (let i = 0; i < 8 && cur; i++) {
      const cas = uniqueCas(collectUrlsIn(cur));
      if (cas.length) return cas[0];
      cur = cur.parentElement;
    }
    return null;
  }

  // 鼠标下面那张卡片对应的币（悬浮窗浮在上面，用 elementsFromPoint 穿透）
  function caFromPointer(root) {
    try {
      const stack = document.elementsFromPoint(lastPointer.x, lastPointer.y) || [];
      for (const el of stack) {
        if (root && (root === el || root.contains(el))) continue;
        const hit = caFromElement(el);
        if (hit) return hit;
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  // 最终判定（越靠前越可信）：
  //   0 浮窗自己 DOM 里的唯一地址（hover 相似币弹出的浮窗，讲的是被 hover 的那个币）
  //   1 详情页 URL 的 CA（页面主体的叙事，铁证）
  //   2 叙事类请求的 CA  3 鼠标下卡片  4 最近 8s 的普请求  5 浮窗内第一个地址
  //
  // 串味根因（用户 2026-11-18 两起）：
  //   a) 列表页 hover Builder Inu，浮窗却显示了页面主体 IDRENT 的叙事 —— 因为老代码
  //      拿「页面 URL 的币」兜底顶掉了 hover 币；
  //   b) hotdog 详情页的浮窗显示了 COST 的叙事 —— 因为「叙事类网络请求」120s TTL 里
  //      混进了 COST 的请求（页面有相似币推荐区 / 预取），把 hotdog 顶掉。
  // 所以：浮窗 DOM 里有唯一地址 → 绝对信它（对应 a）；否则详情页 URL 优先于网络嗅探
  // （对应 b）。网络嗅探只在非详情页、且浮窗里没有地址时才兜底。
  function resolveTarget(root) {
    // 0) 浮窗自己带唯一 CA：这是 hover 某个具体币弹出的浮窗，讲的就是它，谁都不能顶。
    const inRoot = uniqueCas(collectUrlsIn(root));
    if (inRoot.length === 1) return { ...inRoot[0], why: 'popup' };

    // 1) 详情页：URL 里的 CA 就是「我正站在这页看的币」，压过网络嗅探（防 COST 串味）。
    const fromUrl = parseUrlToken(location.href);
    if (fromUrl && /\/token\//i.test(location.pathname)) {
      return { ...fromUrl, why: 'page-url' };
    }

    const ai = netEvents.filter(e => Date.now() - e.ts < NET_AI_TTL &&
      /narrative|analysis|ai_|ai-|social|story|insight/.test(e.path)).pop();
    if (ai) return { ...ai, why: 'network-ai' };

    const under = caFromPointer(root);
    if (under) return { ...under, why: 'pointer' };

    const recent = netEvents.filter(e => Date.now() - e.ts < NET_ANY_TTL).pop();
    if (recent) return { ...recent, why: 'network-recent' };

    if (inRoot.length > 1) return { ...inRoot[0], why: 'popup-multi' };

    // 取不到宁可不替换，也不能显示成另一个币。
    return null;
  }

  function extractChain(root, hint) {
    if (hint && hint.chain) return hint.chain;
    if (hint && hint.ca && !EVM_RE.test(hint.ca)) return 'sol';
    const src = (root?.outerHTML || '') + ' ' + location.pathname;
    if (/\/sol(\/|$|\b)/i.test(src) || /solana/i.test(src)) return 'sol';
    if (/\/base(\/|$|\b)/i.test(src)) return 'base';
    if (/\/eth(\/|$|\b)/i.test(src)) return 'eth';
    if (/\/robin(\/|$|\b)/i.test(src)) return 'robinhood';
    return 'bsc';
  }

  // ===== 定位悬浮窗根容器 =====
  // 读 innerText / getBoundingClientRect 都会触发 layout，交易页上动辄几千个 div，
  // 全量扫会把主线程卡住 —— 用户 2026-11-18 反馈「装了插件后原生数据（K线图）经常
  // 卡顿/加载失败」，根因就是这里的全量 innerText 深扫 + 800ms 轮询一起压主线程。
  // 所以：深扫间隔放宽到 3 秒，且只扫带浮层 class 提示的元素，不再遍历所有 div。
  let knownRoots = [];
  let lastDeepScan = 0;
  const DEEP_SCAN_MS = 15000;   // 深扫保底降到 15s（真正触发靠叙事请求/DOM 变化），不抢主线程

  // 「确实是浮层」的硬判据：fixed/absolute 定位，或明确的 tooltip/popover class。
  // 只看「文本里带 AI 词」会把页面主体（GMGN 那些 AI 情报弹幕、AI 分析区）误判成
  // 叙事浮窗，然后 maskNative 清空它的内容 → React 崩溃 → 主体黑屏（用户 2026-11-18）。
  function isFloatingLayer(el) {
    try {
      const s = getComputedStyle(el);
      if (s.position === 'fixed' || s.position === 'absolute') return true;
      const cls = (typeof el.className === 'string' ? el.className : '').toLowerCase();
      return CONTAINER_HINTS.some(h => cls.includes(h));
    } catch (e) { return false; }
  }

  function findFloatingRoots() {
    const roots = new Set();
    // 初筛：必须是「浮层」，再要求带 AI 叙事特征。两个条件都满足才认。
    for (const hint of CONTAINER_HINTS) {
      document.querySelectorAll(`[class*="${hint}" i]`).forEach(el => {
        if (isVisible(el) && looksLikeAIFloat(el)) roots.add(el);
      });
    }
    // 深扫兜底：只认「确实是浮层」的节点，绝不动页面主体的普通文本。
    if (Date.now() - lastDeepScan > DEEP_SCAN_MS) {
      lastDeepScan = Date.now();
      document.querySelectorAll('div,span,p').forEach(el => {
        if (el.childElementCount > 1) return;
        const txt = el.textContent || '';
        if (txt.length <= 30 || txt.length > 600) return;
        if (!ANCHORS.some(a => txt.includes(a))) return;
        if (!isFloatingLayer(el) && !isFloatingLayer(climbToFloatRoot(el))) return;
        roots.add(climbToFloatRoot(el));
      });
    }
    for (const el of knownRoots) {
      if (el.isConnected && isVisible(el)) roots.add(el);
    }
    const out = [...roots].filter(el => el && el.isConnected && isFloatingLayer(el));
    knownRoots = out;
    return out;
  }
  function isVisible(el) {
    const s = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 120 && r.height > 40;
  }
  function looksLikeAIFloat(el) {
    const txt = el.innerText || '';
    return ANCHORS.some(a => txt.includes(a)) && txt.length > 30;
  }
  function climbToFloatRoot(el) {
    let cur = el;
    // 先看自己是不是浮层；不是再往上找。找不到就返回 null（别把页面主体当浮层）。
    if (isFloatingLayer(cur)) return cur;
    for (let i = 0; i < 6 && cur.parentElement; i++) {
      const p = cur.parentElement;
      const s = getComputedStyle(p);
      const cls = (typeof p.className === 'string' ? p.className : '').toLowerCase();
      const isFloat = ['fixed', 'absolute'].includes(s.position) ||
        CONTAINER_HINTS.some(h => cls.includes(h));
      if (isFloat) return p;
      cur = p;
    }
    return null;
  }

  // ===== 找正文节点（要替换的那段）=====
  function findTextNode(root) {
    let anchorEl = null;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    while (walker.nextNode()) {
      const el = walker.currentNode;
      const t = (el.textContent || '');
      if (ANCHORS.some(a => t.includes(a)) && el.children.length === 0) { anchorEl = el; break; }
    }
    if (!anchorEl) {
      let best = null, bestLen = 0;
      root.querySelectorAll('div,p,span').forEach(el => {
        if (el.children.length <= 1 && (el.innerText || '').length > bestLen) {
          best = el; bestLen = (el.innerText || '').length;
        }
      });
      return best;
    }
    let target = anchorEl.previousElementSibling;
    if (target && (target.innerText || '').length > 15) return target;
    const parent = anchorEl.parentElement;
    if (parent) {
      for (const child of parent.children) {
        if (child !== anchorEl && !ANCHORS.some(a => (child.textContent || '').includes(a)) &&
            (child.innerText || '').length > 15) return child;
      }
    }
    return parent || anchorEl;
  }

  // ===== 调桥接服务 =====
  // cb(text, err, info)：info.reason = 'no-narrative' | 'auth' | 'error'
  const inflight = new Map();  // 同一个 CA 只打一枪：轮询 / DOM 观察 / hover 预热会同时来问

  function peekCache(chain, address) {
    const c = cache.get(chain + ':' + address);
    if (!c) return null;
    const ttl = c.ttl || (c.text ? CACHE_TTL : NO_DATA_TTL);
    return (Date.now() - c.ts < ttl) ? c : null;
  }

  function fetchNarrative(chain, address, cb) {
    const key = chain + ':' + address;
    const hit = peekCache(chain, address);
    if (hit) return cb(hit.text || null, hit.error || null, hit);
    const waiters = inflight.get(key);
    if (waiters) { waiters.push(cb); return; }
    const list = [cb];
    inflight.set(key, list);
    const done = (text, err, info) => {
      inflight.delete(key);
      for (const fn of list) { try { fn(text, err, info); } catch (e) { warn(e); } }
    };
    const url = `${API}/narrative?chain=${encodeURIComponent(chain)}&address=${encodeURIComponent(address)}`;
    GM_xmlhttpRequest({
      method: 'GET', url, timeout: 75000,
      onload(res) {
        const body = res.responseText || '';
        let d = null;
        try { d = JSON.parse(body); } catch (e) { /* 下面统一报错 */ }
        if (d && d.ok && d.text) {
          cache.set(key, { text: d.text, ts: Date.now() });
          schedulePaint(50);          // 叙事刚到手：顺手把卡片染上（不用等下一轮扫）
          done(d.text, null, d);
          return;
        }
        if (d) {
          const info = {
            reason: d.reason || 'error',
            status: d.status || '',
            retryAfter: Number(d.retryAfter || 0),
            error: d.error || '桥接没有返回正文',
          };
          // status=generating 会带 retry_after_seconds（实测 5s）：GIGA X 正在写，很快就有了，
          // 别跟着 2 分钟冷却一起躺平
          const ttl = info.reason === 'no-narrative'
            ? Math.min(NO_DATA_TTL, Math.max(10000, info.retryAfter * 1000 + 2000))
            : NO_DATA_TTL;
          cache.set(key, { text: '', ts: Date.now(), ttl, ...info });
          if (info.reason !== 'no-narrative') warn('桥接返回失败:', info.error);
          done(null, info.error, info);
          return;
        }
        warn('桥接返回非 JSON', 'HTTP', res.status, body.slice(0, 120));
        done(null, `桥接返回非 JSON（HTTP ${res.status}）${body.slice(0, 60).replace(/\s+/g, ' ')}`,
             { reason: 'error' });
      },
      onerror() {
        done(null, '连不上桥接服务 ' + API + '（确认 market-hot-dashboard 主服务 8765 在跑）', { reason: 'error' });
      },
      ontimeout() {
        done(null, '桥接服务超时（GIGA X 侧可能正在续期 token）', { reason: 'error' });
      },
    });
  }

  // ===== 机会标记：从叙事里提关键词，把对应卡片刷成浅蓝底 =====
  // 用户 2026-11-18：把「新机制 / 发射台 / 平台币 / 第一个 / agentic…」这类叙事挑出来，
  // 对应卡片底色变蓝，一眼看出哪个值得先看。
  // **底色必须浅**（原话：「不能太深，不然看不到数据和文字」）——只用 12% 透明蓝 +
  // 一圈 1px 内描边，绝不改文字颜色，也不动布局。
  const HOT_STRONG = [
    '新模式', '新机制', '新玩法', '新叙事', '新范式', '新物种',
    '第一个', '首个', '首家', '首例', '首款', '首创', '首发', '首次',
    '地推', '平台币', '平台原生', '发射台', '发射平台', 'launchpad', 'launch pad',
    'bonding curve', 'agentic',
  ];
  const HOT_WEAK = ['新', '第一'];

  // 标色（用户 2026-11-18 三次校准后的定案）：
  //   1) 「太浅了，深一点」「太浅了，要用亮蓝做浅」→ 不能只靠淡淡一层底色；
  //   2) 「用类似 deepseek logo 的那种蓝」→ 定色 #4D6BFE（rgb 77,107,254），
  //      比 sky-400 深、比宝蓝亮，深色战壕卡片上 30% 就足够醒目。
  // 手法：底色填充 + **2px 同色内描边 + 内发光**，四档只调填充浓度，描边恒亮，
  // 这样任何卡片底色下都看得出来（战壕卡片内层是透明 div，之前就是被它坑了）。
  const HOT_RGB = '77,107,254';     // #4D6BFE —— DeepSeek logo 那个蓝
  const HOT_RING = '#4d6bfe';
  const HOT_ALPHA_STEPS = [0.18, 0.30, 0.42, 0.55];
  let hotAlpha = Number(GM_getValue('hotAlpha', 0.30));
  if (!HOT_ALPHA_STEPS.includes(hotAlpha)) hotAlpha = 0.30;

  function hotCss() {
    const a = hotAlpha;
    const hover = Math.min(0.75, a + 0.10);
    return [
      '.gigax-hot-card{',
      `  background-color:rgba(${HOT_RGB},${a})!important;`,
      `  box-shadow:inset 0 0 0 2px ${HOT_RING}, inset 0 0 38px rgba(${HOT_RGB},.40)!important;`,
      '}',
      `.gigax-hot-card:hover{background-color:rgba(${HOT_RGB},${hover})!important;}`,
    ].join('\n');
  }

  function applyHotCss() {
    let st = document.getElementById('gigax-hot-style');
    if (!st) {
      st = document.createElement('style');
      st.id = 'gigax-hot-style';
      (document.head || document.documentElement).appendChild(st);
    }
    st.textContent = hotCss();
  }
  applyHotCss();
  // 注意：这两条菜单只能注册在声明之后（let 有 TDZ，放文件顶部会 ReferenceError）
  GM_registerMenuCommand(`标记深浅：${Math.round(hotAlpha * 100)}% → 点一下换下一档`, () => {
    const i = HOT_ALPHA_STEPS.indexOf(hotAlpha);
    hotAlpha = HOT_ALPHA_STEPS[(i + 1) % HOT_ALPHA_STEPS.length];
    GM_setValue('hotAlpha', hotAlpha);
    applyHotCss();
    log('标记底色透明度：' + Math.round(hotAlpha * 100) + '%');
  });

  // 命中判定：强词命中 1 个就算；弱词（新 / 第一）要命中 2 个 ——
  // 否则「新增/更新/最新」满屏都是，标记就失去意义了。
  function matchHot(text) {
    if (!text) return [];
    const strong = HOT_STRONG.filter(w => text.includes(w));
    // '新模式' 已经算强词，别再把它里面的 '新' 重复算一个弱词
    const weak = HOT_WEAK.filter(w => text.includes(w) && !strong.some(s => s.includes(w)));
    const pass = hotMode === 'loose'
      ? (strong.length + weak.length) > 0
      : (strong.length >= 1 || weak.length >= 2);
    return pass ? [...new Set(strong.concat(weak))] : [];
  }

  let markedCards = [];
  let paintedAt = 0;
  let paintTimer = null;
  const hotLogged = new Set();

  function schedulePaint(delay) {
    if (paintTimer) return;
    paintTimer = setTimeout(() => { paintTimer = null; paintHotCards(); }, delay || 50);
  }

  // 卡片 = 从代币链接往上爬，爬到「里面只有这一个币」的最大那层。
  // 关键：**优先取最外层「有背景色/背景图」的祖先** —— 战壕榜（trench）那种卡片
  // 里面套了好几层透明 div，只刷最里面那层根本看不见（用户 2026-11-18 反馈）。
  // 但「往上爬」必须有硬边界：GMGN 列表页一行一个币、几十行叠在一个有背景的
  // 滚动容器里，一旦爬到那个容器就会把**整屏列表**染蓝（2026-11-18 截图事故）。
  // 所以两条铁律一起上：
  //   a) 祖先里出现**第二个币的 CA**（任何形式：链接/data-address/title/正文里的
  //      0x 地址）就停 —— 那是列表容器，不是单张卡片；
  //   b) 祖先尺寸超过「单张卡片」上限（过高/过宽）也停 —— 兜底挡住全屏列表。
  function isPainted(el) {
    try {
      const cs = getComputedStyle(el);
      const bg = String(cs.backgroundColor || '');
      const hasBg = bg && bg !== 'transparent' && !/rgba\(0,\s*0,\s*0,\s*0\)/.test(bg);
      const hasImg = String(cs.backgroundImage || 'none') !== 'none';
      return hasBg || hasImg;
    } catch (e) { return false; }
  }

  // 一个「单张代币卡片」的合理上限：GMGN 列表行再高也就 100px 上下，宽不会吃满视口。
  // 超过这个尺度基本就是「整块列表 / 整个面板」，绝不该整块染色。
  const CARD_MAX_H = 240;   // px
  const CARD_MAX_W_RATIO = 0.92; // 相对视口宽度

  // 「第二个币」的判定**只看指向代币详情页的链接**（`/<chain>/token/<CA>` 这类），
  // 不能看 innerText 里的所有 0x 地址 —— GMGN 列表行里合约地址、钱包地址、交易哈希
  // 都是 0x…40，把钱包地址也当成「另一个币」会误判，导致正常该标的行标不上
  // （IDRENT「之前有、现在没了」就是上一版误杀，2026-11-18）。
  function distinctTokenCasIn(el, known) {
    const seen = new Set(known || []);
    try {
      el.querySelectorAll('a[href]').forEach(a => {
        const q = parseUrlToken(a.getAttribute('href'));
        if (q && q.ca) seen.add(q.ca);
      });
    } catch (e) { /* ignore */ }
    return seen;
  }

  function cardFromAnchor(a, ca) {
    // 短缓存：同一个 CA 的卡片定位结果复用（React 重渲染前 anchor 还是同一批）。
    // 命中时校验节点仍连着 DOM，失效（React 换了节点）就重算。这砍掉了
    // 「每次 paint 都对同一批卡片逐祖先读 getComputedStyle」的重复开销。
    const hit = cardCache.get(ca);
    if (hit && hit.isConnected) return hit;

    let painted = null;   // 最外层「有背景」的祖先 = 用户眼里的那张卡片
    let sized = null;     // 没有背景时的兜底（表格行常见）
    const vw = (document.documentElement && document.documentElement.clientWidth) || window.innerWidth || 1280;
    const maxW = vw * CARD_MAX_W_RATIO;
    let cur = a;
    for (let i = 0; i < 10 && cur; i++) {
      const p = cur.parentElement;
      if (!p || p === document.body) break;

      // a) 这一层里出现第二个「代币链接」就停：那是列表容器，不是单张卡片。
      const cas = distinctTokenCasIn(p, [ca]);
      if (cas.size > 1) break;

      const r = p.getBoundingClientRect();
      // b) 尺寸超出一张卡片该有的尺度，停：整块列表 / 面板不染。
      if (r.height > CARD_MAX_H || r.width > maxW) break;

      if (r.width >= 140 && r.height >= 24) {
        if (!sized) sized = p;
        if (isPainted(p)) painted = p;
      }
      cur = p;
    }
    const result = painted || sized;
    if (result) cardCache.set(ca, result);
    return result;
  }
  // CA → 已定位的卡片节点（WeakRef 不行就普通 Map，配合 isConnected 校验防失效）。
  const cardCache = new Map();

  function clearMarks() {
    for (const el of markedCards) {
      try {
        el.classList.remove('gigax-hot-card');
        const t = el.dataset.gigaxTitle;
        if (t != null) {
          if (t) el.setAttribute('title', t); else el.removeAttribute('title');
          delete el.dataset.gigaxTitle;
        }
      } catch (e) { /* 节点可能已被 React 删掉 */ }
    }
    markedCards = [];
  }

  // 记住「标过的币 + 命中词」，重开页面/翻页时不用等网络就先把卡片标上
  // （只存标记结果，不存正文，体积可控）。TTL 给 24 小时：用户「之前标过、隔几小时
  // 回来没了」就是因为 2 小时太短，标记结果本身是缓存的「机会结论」，跨天仍有参考价值。
  const HOT_INDEX_TTL = 24 * 3600 * 1000;
  let hotIndex = GM_getValue('hotIndex', {});
  if (!hotIndex || typeof hotIndex !== 'object') hotIndex = {};
  let hotSaveTimer = null;

  function rememberHot(ca, hits) {
    if (!ca || !hits || !hits.length) return;
    const word = hits.join('、');
    const prev = hotIndex[ca];
    if (prev && prev.h === word) return;
    hotIndex[ca] = { h: word, ts: Date.now() };
    if (hotSaveTimer) return;
    hotSaveTimer = setTimeout(() => {
      hotSaveTimer = null;
      const now = Date.now();
      const out = {};
      let n = 0;
      for (const k of Object.keys(hotIndex)) {
        const v = hotIndex[k];
        if (!v || now - v.ts > HOT_INDEX_TTL) continue;
        out[k] = v;
        if (++n >= 500) break;
      }
      hotIndex = out;
      try { GM_setValue('hotIndex', out); } catch (e) { /* 配额满了就算了 */ }
    }, 2000);
  }

  function paintHotCards(force) {
    if (!force && Date.now() - paintedAt < 800) return;   // 防抖：React 会反复冲掉 class，但 800ms 内重刷足够且不压主线程
    paintedAt = Date.now();
    clearMarks();
    if (hotMode === 'off' || !enabled) return;

    // 先按缓存里的正文判定，再用「上次标过的」补位（顺序覆盖：新结果优先）
    const marks = new Map();
    for (const [key, entry] of cache) {
      if (!entry || !entry.text) continue;
      const hits = matchHot(entry.text);
      if (!hits.length) continue;
      const ca = key.slice(key.indexOf(':') + 1);
      marks.set(ca, hits);
      rememberHot(ca, hits);
    }
    const now = Date.now();
    for (const ca of Object.keys(hotIndex)) {
      if (marks.has(ca)) continue;
      const v = hotIndex[ca];
      if (!v || !v.h || now - v.ts > HOT_INDEX_TTL) continue;
      marks.set(ca, v.h.split('、'));
    }

    // 一次性全页收集 token 链接 → 建 ca→anchor[] 索引，避免每个币各扫一次全页
    // （之前 N 个币各 querySelectorAll 一次 = O(N×M)，现在一次 = O(M)）。
    const anchorIndex = new Map();
    try {
      document.querySelectorAll('a[href*="/token/"]').forEach(a => {
        const p = parseUrlToken(a.getAttribute('href'));
        if (!p || !p.ca) return;
        if (!anchorIndex.has(p.ca)) anchorIndex.set(p.ca, []);
        anchorIndex.get(p.ca).push(a);
      });
    } catch (e) { /* ignore */ }

    const seen = new Set();
    for (const [ca, hits] of marks) {
      const anchors = anchorIndex.get(ca);
      if (!anchors) continue;
      for (const a of anchors) {
        const card = cardFromAnchor(a, ca);
        if (!card || seen.has(card)) continue;
        seen.add(card);
        card.classList.add('gigax-hot-card');
        // 悬停卡片就能看到为什么标蓝（不覆盖 GMGN 自己的 title）
        if (card.dataset.gigaxTitle == null) card.dataset.gigaxTitle = card.getAttribute('title') || '';
        card.setAttribute('title', `GIGA X 叙事命中：${hits.join('、')}`);
        markedCards.push(card);
      }
      if (!hotLogged.has(ca)) {
        hotLogged.add(ca);
        log('机会标记', ca, '|', hits.join('、'));
      }
    }
  }

  // ===== 批量取叙事（一屏一个请求）=====
  // 单个币一个请求、串着发，一屏 20 个要十几秒；改成一次打包，由桥接并发去问 GIGA X。
  // items = [{chain, ca}]；回调参数是「拿到正文的个数」
  function fetchBatch(items, cb) {
    if (!items || !items.length) { cb && cb(0); return; }
    const q = items.map(it => `${it.chain}:${it.ca}`).join(',');
    const url = `${API}/narratives?items=${encodeURIComponent(q)}&workers=8`;
    GM_xmlhttpRequest({
      method: 'GET', url, timeout: 90000,
      onload(res) {
        let d = null;
        try { d = JSON.parse(res.responseText || ''); } catch (e) { /* 下面统一报错 */ }
        if (!d || !d.results) {
          warn('批量返回异常', 'HTTP', res.status, (res.responseText || '').slice(0, 120));
          cb && cb(0);
          return;
        }
        let withText = 0;
        for (const key of Object.keys(d.results)) {
          const p = d.results[key];
          if (!p) continue;
          if (p.ok && p.text) {
            cache.set(key, { text: p.text, ts: Date.now() });
            withText++;
          } else {
            const ttl = Math.min(NO_DATA_TTL,
              Math.max(10000, (Number(p.retryAfter) || 0) * 1000 + 2000));
            cache.set(key, {
              text: '', ts: Date.now(), ttl,
              reason: p.reason || 'error',
              status: p.status || '',
              retryAfter: Number(p.retryAfter) || 0,
              error: p.error || '',
            });
          }
        }
        log('批量结果：', withText, '/', Object.keys(d.results).length, '有正文',
            '| 服务端命中缓存', d.cached || 0);
        schedulePaint(0);
        cb && cb(withText);
      },
      onerror() { warn('批量请求连不上桥接'); cb && cb(0); },
      ontimeout() { warn('批量请求超时'); cb && cb(0); },
    });
  }

  // ===== 自动预取当前屏：不用 hover、不用弹过浮窗，进页面就自己标出来 =====
  // 用户 2026-11-18：「我要的是我没有 hover 它也要自己显示」+「一个币一个币太慢，能不能一批」。
  // 所以这里**按批**发：一次 12 个币打包成一条请求，服务端 8 路并发去问 GIGA X；
  // 允许两条批同时在飞（第一波 12 个先亮，第二波跟上），滚动到新一屏会自动继续。
  const PF_BATCH = 12;           // 一条请求带几个币
  const PF_ROUND_MS = 700;       // 两轮之间至少间隔
  const PF_MAX_FLIGHT = 2;       // 同时最多几条批在飞
  const PF_FAIL_TTL = 2 * 60 * 1000;

  let autoPrefetchOn = GM_getValue('autoPrefetch', true);
  let pfInFlight = 0;
  let pfLastRound = 0;
  const pfPending = new Set();   // 已发出去还没回来的 key（避免下一轮重复发）
  const pfFailed = new Map();    // key -> ts（撞墙的先冷一会儿）

  function viewportTargets() {
    // 结果短缓存：同一批锚点的 getBoundingClientRect 结果在 500ms 内复用，
    // 避免 autoPrefetch 每 700ms 就对全页 token 链接重排一次 layout。
    const now = Date.now();
    if (vpCache.at && now - vpCache.at < 500) return vpCache.list;

    const out = [];
    const seen = new Set();
    const de = document.documentElement || document.body || {};
    const vh = de.clientHeight || (typeof innerHeight === 'number' ? innerHeight : 800);
    const vw = de.clientWidth || (typeof innerWidth === 'number' ? innerWidth : 1200);
    for (const a of document.querySelectorAll('a[href*="/token/"]')) {
      if (out.length >= 40) break;
      const p = parseUrlToken(a.getAttribute('href'));
      if (!p || !p.ca || seen.has(p.ca)) continue;
      const r = a.getBoundingClientRect();
      if (!r.width || r.bottom < -40 || r.top > vh + 40 || r.right < 0 || r.left > vw) continue;
      seen.add(p.ca);
      out.push({ chain: p.chain, ca: p.ca, el: a, top: r.top });
    }
    out.sort((x, y) => x.top - y.top);      // 从上往下取：视野里先看到的先亮
    vpCache = { at: now, list: out };
    return out;
  }
  let vpCache = { at: 0, list: [] };

  function autoPrefetch() {
    if (!autoPrefetchOn || document.hidden) return;
    if (pfInFlight >= PF_MAX_FLIGHT) return;
    const now = Date.now();
    if (now - pfLastRound < PF_ROUND_MS) return;
    pfLastRound = now;

    const items = [];
    const keys = [];
    for (const t of viewportTargets()) {
      if (items.length >= PF_BATCH) break;
      const chain = extractChain(t.el, t);
      const key = chain + ':' + t.ca;
      if (pfPending.has(key)) continue;
      const failedAt = pfFailed.get(key);
      if (failedAt && now - failedAt < PF_FAIL_TTL) continue;
      if (peekCache(chain, t.ca)) continue;
      items.push({ chain, ca: t.ca });
      keys.push(key);
    }
    if (!items.length) return;

    pfInFlight++;
    items.forEach(k => pfPending.add(k));
    log('批量预取', items.length, '个（在飞', pfInFlight, '批）');
    fetchBatch(items, (n) => {
      pfInFlight = Math.max(0, pfInFlight - 1);
      keys.forEach(k => pfPending.delete(k));
      if (!n) keys.forEach(k => pfFailed.set(k, Date.now()));
      log('本批完成：', n, '/', items.length, '有正文');
    });
  }

  // ===== 渲染 / 还原 =====
  // 两条铁律（用户 2026-11-18 反馈）：
  //   1 不能先露出 GMGN 原生的 AI 叙事再跳成 GIGA X 的 —— 所以**先遮住再发请求**；
  //   2 GIGA X 说「没有这个币」时一个字都不要动（不写红字、不清空），保留原文。
  const LOADING_HTML =
    '<span style="color:#8b8b9a;font-style:italic;">GIGA X 叙事加载中…</span>';
  const MAX_ATTEMPTS = 3;      // 真错误（断网/token）的重试次数
  const RETRY_MS = 8000;       // 重试间隔
  const HARD_FAIL_MS = 60000;  // 连着失败后，先放弃一会儿，别再每 700ms 抖一次

  // 记住每个浮层用的是哪个正文节点：React 重渲染后 findTextNode 可能挑到别的节点，
  // 那会把还原的内容塞进错误的地方（出现重复文案）。
  const nodeMap = new WeakMap();
  function nodeOf(root, refresh) {
    if (!refresh) {
      const n = nodeMap.get(root);
      if (n && n.isConnected) return n;
    }
    const n = findTextNode(root);
    if (n) nodeMap.set(root, n);
    return n;
  }

  // 原文快照：只在「这次读到的是 GMGN 的东西」时更新，且取更长的那个
  // （第一次看到时文案可能还没渲染完，别把半截存成原文）
  function saveOrig(root, node) {
    const cur = node.innerHTML || '';
    if (cur.includes('GIGA X')) return;
    const prev = root.dataset.gigaxOrig;
    if (prev == null || cur.length > prev.length) root.dataset.gigaxOrig = cur;
  }

  function maskNative(root) {
    const node = nodeOf(root);
    if (!node) return false;
    if ((node.innerText || '').includes('GIGA X')) return true;   // 已经是我们的内容
    saveOrig(root, node);
    node.innerHTML = LOADING_HTML;
    return true;
  }

  function renderNarrative(root, text, ca, chain) {
    const node = nodeOf(root);
    if (!node) { warn('找不到正文节点'); return false; }
    saveOrig(root, node);
    node.innerHTML = '';
    const badge = document.createElement('span');
    badge.textContent = '【GIGA X 叙事】 ';
    badge.style.cssText = 'color:#7c5cff;font-weight:700;';
    // 悬停能看到用的是哪个地址，对不上时一眼可查
    badge.title = `GIGA X 按 ${chain}:${ca} 取叙事`;
    node.appendChild(badge);
    node.appendChild(document.createTextNode(text));
    root.dataset.gigaxDone = '1';
    if (ca) root.dataset.gigaxCa = ca;
    delete root.dataset.gigaxPending;
    delete root.dataset.gigaxAttempts;
    delete root.dataset.gigaxRetryAt;
    nodeMap.set(root, node);
    log('已替换:', chain + ':' + ca, '|', text.slice(0, 40) + '…');
    return true;
  }

  // 只把正文还回去，保留标记（done/retryAt 由调用方决定）
  function restoreContent(root) {
    const node = nodeOf(root);
    if (!node) return;
    const orig = root.dataset.gigaxOrig;
    if (orig) { node.innerHTML = orig; return; }
    // 原文本来就是空的：只撤掉我们自己的占位，
    // 千万别把 React 在这期间写进来的原生文案一起抹掉（那会留下一个永久空白框）
    if ((node.innerHTML || '').includes('GIGA X')) node.innerHTML = '';
  }

  function resetRoot(root) {
    restoreContent(root);
    nodeMap.delete(root);
    delete root.dataset.gigaxOrig;
    delete root.dataset.gigaxDone;
    delete root.dataset.gigaxCa;
    delete root.dataset.gigaxNetAt;
    delete root.dataset.gigaxAttempts;
    delete root.dataset.gigaxRetryAt;
    delete root.dataset.gigaxPending;
  }

  function restoreAll() {
    document.querySelectorAll('[data-gigax-done],[data-gigax-pending]').forEach(resetRoot);
    clearMarks();
  }

  // 结果落地：有正文就换上；「没有」就悄悄还原；真错误才重试
  function settle(root, text, err, info, ca, chain) {
    delete root.dataset.gigaxPending;
    if (text) { renderNarrative(root, text, ca, chain); return; }

    if (info && info.reason === 'no-narrative') {
      restoreContent(root);
      root.dataset.gigaxDone = '2';           // 2 = 已知 GIGA X 没这个币
      root.dataset.gigaxCa = ca || '';
      root.dataset.gigaxNetAt = String(netVersion);
      // status=generating 时 5 秒后再看一眼（GIGA X 正在写），别一躺就是两分钟
      root.dataset.gigaxRetryAt =
        String(Date.now() + Math.max(5000, (info.retryAfter || 0) * 1000 + 1500));
      log('GIGA X 暂无该币叙事，保留原文：', chain + ':' + ca, info.status || '');
      return;
    }

    const attempts = Number(root.dataset.gigaxAttempts || '0') + 1;
    root.dataset.gigaxAttempts = String(attempts);
    restoreContent(root);
    if (attempts < MAX_ATTEMPTS) {
      root.dataset.gigaxRetryAt = String(Date.now() + RETRY_MS);
      warn(`第 ${attempts} 次失败，${RETRY_MS / 1000}s 后重试：`, err);
      return;
    }
    // 彻底失败：还原文，别在页面上留一个红框
    root.dataset.gigaxDone = '3';             // 3 = 放弃
    root.dataset.gigaxRetryAt = String(Date.now() + HARD_FAIL_MS);
    warn('放弃替换，保留 GMGN 原文：', chain + ':' + ca, err);
  }

  // ===== 调试：打印悬浮窗 DOM =====
  function dumpFloating() {
    const roots = findFloatingRoots();
    log('调试：找到悬浮窗根', roots.length, '个');
    roots.forEach((r, i) => {
      log(`--- root ${i} ---`, r.tagName, r.className);
      log(r.outerHTML.slice(0, 2500));
      const node = findTextNode(r);
      log('正文节点:', node ? node.tagName + '.' + node.className : 'null',
          node ? (node.innerText || '').slice(0, 120) : '');
      const t = resolveTarget(r);
      log('解析结果:', t ? `${t.chain || '?'}:${t.ca}（来源 ${t.why}）` : 'null',
          '| 浮层内地址数:', uniqueCas(collectUrlsIn(r)).length,
          '| 最近网络事件:', netEvents.slice(-4).map(e => `${e.chain || '?'}:${e.ca.slice(0, 8)}…(${e.path.slice(0, 40)})`));
    });
    if (!roots.length) warn('没找到悬浮窗。请在 GMGN 上 hover/点开一个代币的 AI 叙事悬浮窗后再按 Alt+G');
  }
  document.addEventListener('keydown', e => {
    if (e.altKey && e.key.toLowerCase() === 'g') { e.preventDefault(); dumpFloating(); }
  });

  // ===== 主循环 =====
  function scan() {
    if (!enabled) return;
    for (const root of findFloatingRoots()) {
      const state = root.dataset.gigaxDone;

      if (state === '1') {
        // 我们还塞着内容就跳过；被 React 重渲染冲掉了就重来
        const node = nodeOf(root);
        if (node && (node.textContent || '').includes('GIGA X 叙事')) continue;
        resetRoot(root);
      } else if (state === '2') {
        // 已知 GIGA X 没这个币：换币（GMGN 又发了叙事请求 / 鼠标移到别的卡片）或冷却到点才重判。
        // 不重判的话，同一个浮层换成下一个币时会一直保持原文 —— 那正是「有些币没有」的另一半原因。
        const until = Number(root.dataset.gigaxRetryAt || '0');
        if (until > Date.now() && Number(root.dataset.gigaxNetAt || '0') === netVersion) continue;
        resetRoot(root);
      } else if (state === '3') {
        if (Number(root.dataset.gigaxRetryAt || '0') > Date.now()) continue;
        resetRoot(root);
      }

      if (root.dataset.gigaxPending === '1') {
        // 请求还在路上：React 可能把原生文案又写回来了，继续按住
        const node = nodeOf(root);
        if (node && !(node.innerText || '').includes('GIGA X')) maskNative(root);
        continue;
      }
      if (Number(root.dataset.gigaxRetryAt || '0') > Date.now()) continue;

      // 取址放在所有早退之后：resolveTarget 会扫 DOM，别白跑
      const target = resolveTarget(root);
      const ca = target ? target.ca : null;
      if (!ca) {
        // 取不到就退避 3 秒：否则每 200ms 刷一次 console，除了吵没别的用
        root.dataset.gigaxRetryAt = String(Date.now() + 3000);
        warn('悬浮窗未提取到 CA，3s 后重试', root);
        continue;
      }
      const chain = extractChain(root, target);
      const key = chain + ':' + ca;

      const cached = peekCache(chain, ca);
      if (cached) {
        // 命中缓存：有正文立刻换上；没正文就一个字都不动（避免「加载中 → 原文」抽搐）
        if (cached.text) renderNarrative(root, cached.text, ca, chain);
        else if (cached.reason === 'no-narrative') {
          root.dataset.gigaxDone = '2';
          root.dataset.gigaxCa = ca;
          root.dataset.gigaxNetAt = String(netVersion);
          root.dataset.gigaxRetryAt =
            String(Date.now() + Math.max(5000, (cached.retryAfter || 0) * 1000 + 1500));
        } else if (cached.reason) {
          root.dataset.gigaxDone = '3';
          root.dataset.gigaxRetryAt = String(Date.now() + HARD_FAIL_MS);
        }
        continue;
      }

      log('检测到悬浮窗', key, '来源=', target.why);
      maskNative(root);                       // 先遮住原生正文，再问桥接
      root.dataset.gigaxPending = '1';
      root.dataset.gigaxCa = ca;
      fetchNarrative(chain, ca, (text, err, info) => settle(root, text, err, info, ca, chain));
    }
    // React 重渲染会把卡片上的 class 冲掉，每轮顺手重刷一次（内部有 400ms 防抖）
    if (cache.size) schedulePaint(0);
  }

  // 「提前显示颜色标记」不依赖 scan 的重节奏：autoPrefetch 自己跑一个 700ms 的
  // 独立定时器（轻量：只发请求，不扫 DOM），进页面就立刻开始预取 + 标色。
  // 而 scan（浮窗识别，重）走 5s 保底 + 事件驱动 —— 两者解耦，互不拖累。
  const idleCb = (typeof requestIdleCallback === 'function')
    ? requestIdleCallback.bind(window)
    : (fn) => setTimeout(fn, 50);
  function autoPrefetchLoop() {
    if (enabled && !document.hidden) {
      idleCb(() => autoPrefetch(), { timeout: 200 });
    }
  }
  setInterval(autoPrefetchLoop, 700);

  // 扫描节流：轮询 + DOM 变化 + hover 三条路都会来调，合并成最快 250ms 一次。
  // 用 requestIdleCallback 跑，让 scan 只在浏览器空闲时执行，绝不和 GMGN 的渲染抢主线程。
  let lastScanAt = 0;
  function scheduleScan(delay) {
    if (scheduleScan._t) return;
    const wait = Math.max(delay || 80, 250 - (Date.now() - lastScanAt));
    scheduleScan._t = setTimeout(() => {
      scheduleScan._t = null;
      lastScanAt = Date.now();
      idleCb(() => scan(), { timeout: 300 });
    }, wait);
  }

  // 保底轮询大幅降频到 5 秒，且走 idle：真正触发扫描的是「叙事类网络请求 / DOM 变化 /
  // hover」，这个 setInterval 只是兜底（防漏网），不再是每 1.5s 压一次主线程。
  setInterval(() => scheduleScan(0), 5000);

  // DOM 一变就扫：悬浮窗是 React 现插的，等 800ms 轮询才反应就是「先看到原生文案」的根源。
  // 全量扫有 1 秒节流，所以这里只对「看着像叙事浮层」的变更强制放开节流。
  function looksLikeNarrative(node) {
    if (!node || node.nodeType !== 1) return false;
    const cls = typeof node.className === 'string' ? node.className.toLowerCase() : '';
    if (CONTAINER_HINTS.some(h => cls.includes(h))) return true;
    const t = node.textContent || '';
    return ANCHORS.some(a => t.includes(a));
  }
  try {
    // GMGN 是 React 重渲染极其频繁的页面（K线每秒 tick、行情条实时刷），
    // MutationObserver 挂 subtree 会每个 tick 都触发。这里加一层粗粒度早退：
    // 只有 mutation 里真的出现「叙事特征」节点才 scheduleScan，其余直接忽略，
    // 绝不让插件在每一个行情 tick 上都去读 textContent 触发 reflow。
    const mo = new MutationObserver(muts => {
      // 大量小 mutation（价格数字刷新）时快速跳过：先扫一眼有没有类名/文本特征。
      for (const m of muts) {
        if (m.type === 'characterData') {
          if (looksLikeNarrative(m.target.parentElement)) { lastDeepScan = 0; scheduleScan(40); return; }
          continue;
        }
        for (const n of m.addedNodes) {
          if (looksLikeNarrative(n)) { lastDeepScan = 0; scheduleScan(40); return; }
        }
      }
    });
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    log('DOM 观察已挂');
  } catch (e) { warn('MutationObserver 挂载失败', e); }

  // hover 预热：鼠标停在某个币的卡片/AI 按钮上时就先去取一次。
  // GMGN 的悬浮窗要 hover 之后才渲染，等它出现时缓存已经命中 —— 用户看不到原生文案。
  let hoverTimer = null;
  let lastHoverAt = 0;
  let lastHoverCa = null;
  let prefetchDepth = 0;
  document.addEventListener('pointerover', e => {
    if (!enabled) return;
    if (Date.now() - lastHoverAt < 120) return;
    lastHoverAt = Date.now();
    const hit = caFromElement(e.target);
    if (!hit) { lastHoverCa = null; return; }
    if (hit.ca !== lastHoverCa) {
      lastHoverCa = hit.ca;
      netVersion++;    // 换了个币 ≈ 悬浮窗内容要换，作废「已知无数据」标记
    }
    const el = e.target;
    if (hoverTimer) clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => {
      const chain = extractChain(el, hit);
      if (peekCache(chain, hit.ca)) return;
      if (prefetchDepth >= 2) return;   // 鼠标扫过一长串卡片时别把桥接打爆
      prefetchDepth++;
      log('预热叙事：', chain + ':' + hit.ca);
      fetchNarrative(chain, hit.ca, () => { prefetchDepth--; });
    }, 180);
  }, { passive: true, capture: true });

  log('已加载 v1.5.1。桥接=', API, ' 开关=', enabled ? '开' : '关', ' 机会标记=', hotMode);
  log('机会标记：叙事里出现「新机制/发射台/平台币/第一个/agentic…」时，对应卡片刷蓝底（菜单可关/可放宽/可调深浅）');
  log('自动预取：', autoPrefetchOn ? '开（按批，一屏一个请求，不用 hover）' : '关');
  log('取址优先级：叙事类请求 > 浮层内唯一地址 > 鼠标下卡片 > 最近普请求 > 浮层内首个地址');
  log('命中缓存的悬浮窗直接替换；未命中先遮住原生正文，GIGA X 说没有就原样还回去');
  log('快捷键 Alt+G 打印悬浮窗 DOM（含取址来源）；菜单里可开关/改桥接地址');
})();
