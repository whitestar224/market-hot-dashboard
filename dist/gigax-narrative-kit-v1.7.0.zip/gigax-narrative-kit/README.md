# GIGA X 叙事桥接 + GMGN 悬浮窗替换

把 GMGN 网页端代币卡片上的「AI 叙事」悬浮窗，替换成 GIGA X 对同一代币生成的叙事分析。

GIGA X 的叙事接口需要登录态，而 token 只存在手机 App 里；所以这里用**桥接**的方式：
浏览器里的油猴脚本调你本机的 HTTP 服务，由服务拿 token 去代调 GIGA X。

```
GMGN 页面 (Tampermonkey)
        │  GET http://127.0.0.1:8765/api/gigax/narrative?chain=bsc&address=0x...
        ▼
  桥接服务 (bridge/gigax.py)
        │  ① 需要时先向 Privy 续期：POST auth.privy.io/api/v1/sessions
        │  ② GET app-api.gigax.fun/api/data/token/narrative
        ▼
   返回 { ok, text, timeline, ... } → 脚本把悬浮窗正文替换掉
```

---

## 一、目录结构

```
gigax-narrative-kit/
├── bridge/
│   ├── gigax.py          桥接核心：续期 + 调叙事接口 + 保活（纯标准库）
│   ├── server.py         独立 HTTP 服务（不想动你现有后端时用它）
│   ├── config.json       你的配置（由 config.example.json 复制而来，不要外发）
│   └── .state/           运行时目录：captured.json（token）、securestore_dump.json
├── tools/
│   ├── gigax_securestore_dump.py   从 Android 模拟器解出 token（frida）
│   └── gigax_tls_tap.py            需要重新逆向接口时抓 HTTPS 明文（可选）
├── userscript/
│   └── gmgn-gigax-narrative.user.js
├── config.example.json
├── captured.example.json
└── README.md
```

**包里没有任何 token、App ID、设备 ID。** token 在你第一次运行时才生成，
App/Client ID 由你自己从 APK 里取（见下文）。

---

## 二、前置条件

| 用途 | 需要 |
| --- | --- |
| 长期跑桥接 | Python 3.10+（只用标准库） |
| 首次获取 token | 一台能装 GIGA X 的 Android 模拟器（已登录）、带 root、`frida` **16.x** 与 `frida-server` 同版本 |
| 浏览器 | Tampermonkey / Violentmonkey |

> `frida` 官方只提供到 3.10/3.11 的 wheel，建议单独建一个 3.10 环境装 `frida==16.7.19`，
> 再用 `config.json` 的 `fridaPython` 指过去。桥接本身不需要 frida。

---

## 三、快速开始

### 1. 填配置

```bash
cp config.example.json bridge/config.json
```

几个 ID 在 APK 的 `assets/app.config`（JSON）里，路径 `extra.privy`：

| 字段 | 从哪来 |
| --- | --- |
| `privyAppId` | `extra.privy.appId` |
| `privyClientId` | `extra.privy.androidClientId`（**必须是 `client-XXXX` 这种**） |
| `nativeAppId` | APK 包名，如 `family.giga.app` |
| `privyClientVersion` | 抓包里的 `privy-client` 头，留默认 `expo:0.74.3` 通常可用 |
| `privyCaId` | 可留空，留空会自动生成一个 UUID 并复用；续期报错时再从抓包里拷真实值 |
| `adb` / `fridaPython` | 可留空，留空自动探测 PATH 与 Android SDK |

> 解 APK 不用装 Android Studio：`unzip app.apk assets/app.config -d out` 即可。

### 2. 拿第一份 token（只需一次）

1. 启动模拟器，打开 GIGA X 并**登录**，停在任意页面别退出；
2. 起 frida-server（16.x，例如 `adb shell su -c "/data/local/tmp/fs16 -l 0.0.0.0:27044"`），
   `adb forward tcp:27044 tcp:27044`；
3. 跑：

```bash
python tools/gigax_securestore_dump.py --adb <adb路径>
```

它会在模拟器里用 App 自己的 Keystore 密钥解出 `SecureStore`，打印并落盘
`bridge/.state/securestore_dump.json`（含 access token + refresh token）。

### 3. 把 token 灌进桥接

```bash
python - <<'PY'
import base64, json, pathlib
dump = json.loads(pathlib.Path("bridge/.state/securestore_dump.json").read_text("utf-8"))
dec = lambda k: base64.b64decode(dump[k]["b64"]).decode()
state = pathlib.Path("bridge/.state") / "captured.json"
state.parent.mkdir(parents=True, exist_ok=True)
state.write_text(json.dumps({
    "token": dec("key_v1-privy-token"),
    "refreshToken": dec("key_v1-privy-refresh_token"),
}, ensure_ascii=False, indent=2), "utf-8")
print("ok")
PY
```

### 4. 起桥接

```bash
python bridge/server.py --port 8765
curl http://127.0.0.1:8765/api/gigax/health
```

`hasToken=true`、`hasRefreshToken=true`、`expiresInSeconds` 为正即正常。
**从这一刻起就不用再开模拟器了**：进程每 30 分钟自动续一次，token 到期前 5 分钟内的请求也会自动续。

### 5. 装油猴脚本

Tampermonkey → 新建脚本 → 粘贴 `userscript/gmgn-gigax-narrative.user.js` → 保存。
打开 `gmgn.ai`，把鼠标移到任意代币的 AI 叙事图标上，悬浮窗正文应变成
`【GIGA X 叙事】…`。徽标悬停能看到本次用的是 `链:地址`。

---

## 四、怎么判断「这笔叙事属于哪个币」

悬浮窗 DOM 里常常**没有合约地址**，所以脚本按可信度取址，越靠前越优先（**1.7.0 定案**）：

| 优先级 | 来源（徽标 `title` 里的 `地址来源`） | 说明 |
| --- | --- | --- |
| **0** | **`data`** | **GMGN 自己写在 DOM 上的 data 属性**，见下节。同一张卡自己的、唯一的、机器可读的地址 |
| 1 | `popup` | 浮窗 DOM 内**只有一个**地址 —— 浮窗自带地址就是铁证 |
| 2 | `hover` / `hover-sym` | hover **当时**记下的那张卡片（CA + 矩形 + symbol）。浮窗是 hover 卡片弹出来的，它就是正主 |
| 3 | `pointer` | 鼠标下那张卡片（`elementsFromPoint` 穿透**所有**浮层） |
| 4 | `popup-multi` | 浮层内多个地址时，取能和 hover / 指针 / URL 对上的那个（不再盲取第一个） |
| 5 | `page-url` | 详情页 URL 的 CA（只认 `/<chain>/token/<CA>` 形态） |
| 6 | `network-ai` | 叙事类请求（narrative / analysis / social）里的地址，30 秒内有效；**且必须能在页面上找到这个币**，否则一律不用 |
| — | 放弃 | 以上全取不到 → 保留 GMGN 原文，绝不换成别的币 |

### 第 0 优先：GMGN 的 data 属性（1.7.0，用真实浏览器实测出来的）

2026-11-19 用 `chrome-devtools-mcp` 打开真实的 `https://gmgn.ai/?chain=bsc`（战壕页，30 张卡）实测：

```html
<!-- 右侧战壕卡：一卡一个，30 个 holder / 30 个不同 CA，尺寸正好 326×144 -->
<div data-trenches-token-address="0x44b92e572cba406ad62ba2d10393eff940837777"
     data-trenches-token-chain="bsc"
     data-trenches-token-key="0x44b92e…7777-bsc">

<!-- 左侧榜单行：一行一个（虚拟列表的键） -->
<div data-row-key="bsc:0xb82535e74b03ffe4910efea1c759b6bbbf0a7777" …>
<div data-recycler-key="bsc:0xb82535e74b03ffe4910efea1c759b6bbbf0a7777" …>
```

**为什么这条是决定性的**（也是之前十几轮反复出错的真正原因）：

- 战壕卡片里 `a[href*="/token/"]` 的个数实测是 **0 / 1 / 2 个**，币名（`NVIDIASI`）是**纯文本节点**、
  根本不是链接。老版本靠代币链接找币 → 战壕区要么一无所获（退到网络嗅探，于是**全变成同一个币**），
  要么往上爬到列容器、取到**下面那张卡**的链接（IDRENT 显示成慈善CZ 就是这么来的）。
- 同一屏实测存在**同名不同币**：两张卡都叫 `PENGB Penguin Solutions`（`0x0c58…ffff` / `0xd962…ffff`）、
  都叫 `NVIDIASI`（`0x44b9…7777` / `0x407a…ffff`）。所以「靠 symbol 认币」从根上不可靠 ——
  能拿到地址就绝不靠名字。
- 虚拟列表会**复用同一个 DOM 节点**给另一个币（`data-recycler-key` 一变就换币）。所以脚本另外挂了
  一个只盯这三个属性的 `MutationObserver`：换币即重刷标色，节点上还留了 `data-gigax-ca` 做校验。
  这是「标过的卡片一会儿又没了 / 变成别的币还带着蓝底」的物理原因。

实测覆盖率（同一页面，每张卡取 4 个内缩采样点，走「指针 → `elementsFromPoint` → 取址」全链路）：

| 区域 | 采样点 | 命中 | 认错 | 说明 |
| --- | --- | --- | --- | --- |
| 右侧战壕卡 | 60 | **60** | **0** | 100% |
| 左侧榜单行 | 44 | 34 | **0** | 未命中的 10 个点全部落在 `GlobalCalloutPanel`（可拖动的喊单浮窗）上 —— 浮层盖住了列表，本来就点不到卡片 |

三条硬规矩（都是踩过坑换来的）：

- **能读 data 属性就绝不猜**：`data-trenches-token-address` / `data-row-key` = 卡片自带的地址；
  只有 GMGN 没给属性的地方（如详情页正文）才退到链接/浮层/网络。
- **向上找祖先必须从里往外停**：遇到第一个「卡片大小」且带地址的祖先就停，不能一路爬到最外层 ——
  一列里相邻两张卡会被同一个列容器包住，爬到那层就等于把两张卡当成一张。
- **浮层容器会被复用**：GMGN 换币时不一定重写正文节点，「里面还是我们写的内容」**不等于**
  「已经处理好了」。每轮都要校验「现在这个浮层讲的是哪个币」，换了就整块重来。
- **叙事请求只是佐证，不能当主证**：GMGN 会预取相邻卡片，浮窗里出现「上一个 hover 的币」
  的叙事是常态。所以它排在最后，且要能在页面上找到这个币。
- **响应回来要验币**：GIGA X 生成要几秒，这期间浮窗可能已经换成另一个币 ——
  此时丢弃该正文，让下一轮按新币重取（命中缓存，不会再打网络）。

调试：在 GMGN 页面按 `Alt+G`，控制台会打印每个悬浮窗的 DOM、
`解析结果: bsc:0x…（来源 hover）`，以及最近四条网络事件。按 **`Alt+Shift+G`** 则直接在页面上
弹一个诊断面板，逐个列出当前屏的币：有没有取到叙事、命不命中关键词、卡片找没找到、多大、
有没有背景色 —— 哪张卡没标上一眼就能看出卡在哪一步。普通使用时也可以把鼠标停在
`【GIGA X 叙事】` 徽标上，`title` 会写明用的是哪个地址、地址是怎么认出来的。

### 替换时机（1.3.0 起）

悬浮窗是 React 现插的，等轮询才发现就一定会「先闪一下 GMGN 原生文案」。所以：

1. **hover 预热**：鼠标停在卡片/AI 按钮上 180ms 后就去取一次，等浮窗真的出现时缓存已命中；
2. **DOM 观察**：出现像叙事浮层的节点立刻扫（全量扫另有 1 秒节流），不等轮询；
3. **未命中缓存就先遮住**原生正文（显示「GIGA X 叙事加载中…」），拿到结果再落地；
4. **GIGA X 说没有这个币**（`reason: "no-narrative"`）时**一个字都不动**，保留 GMGN 原文，
   不写红字、不清空；同一浮层换币后自动重判；
5. 真错误（断网/鉴权）重试 3 次，仍失败也还原文，页面上不留错误框。

> base58 地址（Solana）**绝不能小写化**，小写后是另一个地址，GIGA X 会回
> `{"code":-1,"msg":"Invalid token address"}`。脚本里这类返回按「没这个币」处理，不会报错。

### 自动预取与机会标记（1.4.0 起，1.5.0 起按批）

进页面**不需要 hover**：脚本每 0.7 秒把视野里的代币打包成一条 `/api/gigax/narratives` 请求
（一次最多 12 个、允许两批同时在飞、从上往下取），服务端 8 路并发去问 GIGA X。
实测 8 个冷币一条请求 10.6 秒、再请求一次 0.13 秒（全走缓存）。

叙事到手后做关键词匹配，命中就把**那张代币卡片的底色刷成蓝**：

| 强度 | 关键词 |
| --- | --- |
| 强（命中 1 个即标） | 新模式 / 新机制 / 新玩法 / 新叙事 / 新范式 / 新物种 / 第一个 / 首个 / 首家 / 首例 / 首款 / 首创 / 首发 / 首次 / 地推 / 平台币 / 平台原生 / 发射台 / 发射平台 / launchpad / launch pad / bonding curve / agentic |
| 弱（命中 2 个才标） | 新 / 第一 |

弱词单独不触发，否则「新增 / 更新 / 最新」满屏都是。悬停卡片会显示命中了哪些词；
**详情页顶部那条（当前正在看的币）不标**，那里刷蓝太吵。

样式用 **DeepSeek logo 那个蓝 `#4D6BFE`**：底色 `rgba(77,107,254,.30)` + **2px 实心同色内描边** + 内发光，
菜单里填充浓度可在 18/30/42/55% 循环（描边恒亮，深色卡片上也看得见）。只改底色和描边，不动文字颜色、不动布局。

> 卡片定位会**优先挑最外层「有背景色/背景图」的祖先**：战壕榜那种卡片里套了多层透明 div，
> 只刷最内层等于没刷（2026-11-18 实测反馈）。

标记结果会存进 `GM_setValue('hotIndex')`（2 小时），**重开页面先标上再慢慢刷新**，
不用干等网络。

菜单里可以：关闭标记 / 严格与宽松切换（宽松 = 任一关键词就标）/ 循环改底色深浅 / 关掉自动预取。


---

## 五、接口

| 路由 | 说明 |
| --- | --- |
| `GET /api/gigax/health` | token / refresh token 状态、剩余秒数、refresh token 已用天数 |
| `GET /api/gigax/narrative?chain=bsc&address=0x…` | 取单个币的叙事；`chain` 支持 `sol/eth/bsc/base/robinhood/arc/elysium` |
| `GET /api/gigax/narratives?items=sol:CA1,bsc:0x…&workers=8` | **批量**：一条请求取多个币，服务端并发（默认 6 路）。返回 `{results:{"sol:CA":{…}}}`，命中进程内缓存的不再打 GIGA X |
| `GET /api/gigax/refresh` | 强制续期一次 |
| `OPTIONS /api/gigax/*` | 浏览器预检，返回 204 |

返回示例：

```json
{
  "ok": true,
  "reason": null,
  "text": "……叙事正文……",
  "originalText": "……原文……",
  "categoryTags": ["meme"],
  "generatedAt": "2026-11-18T09:12:05Z",
  "timeline": [{ "summary": "…", "url": "https://x.com/…" }],
  "status": "ready"
}
```

拿不到正文时 `ok: false`，`reason` 区分三种情况（**前端行为不同，别混用**）：

| `reason` | 含义 | 前端该怎么做 |
| --- | --- | --- |
| `no-narrative` | GIGA X 没这个币 / 正在生成 / 地址不合法 | 保留原文，按 `retryAfter` 秒后再看 |
| `auth` | token 失效且续期失败 | 重试几次，仍失败保留原文 |
| `error` | 网络或未预期的返回 | 同上 |

```json
{ "ok": false, "reason": "no-narrative", "status": "generating", "retryAfter": 5,
  "error": "GIGA X 暂无该币叙事" }
```


### 嵌进已有后端时

把 `bridge/gigax.py` 放进你的项目（例如 `app/api/gigax.py`），加三条路由即可：

```python
from app.api import gigax

# GET /api/gigax/health
payload = gigax.health()

# GET /api/gigax/narrative?chain=&address=
payload = gigax.fetch_narrative(chain, address)

# 启动时挂保活
gigax.start_keepalive()
```

**两个必踩的坑**：

1. **不要对这些路由启用 gzip**。油猴的 `GM_xmlhttpRequest` 不会自动解压，
   返回压缩字节会让脚本 `JSON.parse` 失败，表现为「桥接返回非 JSON」。
2. 路由前缀是 `/api/gigax/`，油猴脚本里只填**根地址**（`http://127.0.0.1:8765`），
   带不带路径脚本都会自己归一化处理。

### 让系统里其它叙事入口也走 GIGA X

榜单行、战壕卡、桌面弹窗这些「叙事分析」入口原来各打各的币安 AI。现在统一在一处收口：

```python
# 单条：GIGA X 优先，命中直接返回；没命中才按开关回落币安 / Bitget
item = exchange_ai_narrative_for_item({"sourceId": "gmgn-trenches", "chain": "sol",
                                       "contractAddress": "<CA>", "symbol": "XXX"})

# 榜单预取：同一套顺序，并把结果同时写成 exchangeAi* 与 binanceAiNarrative*
source = enrich_binance_wallet_ai_narratives(source)
```

- 链别名先过 `GIGAX_EXCHANGE_AI_CHAINS`（`56`/`bnb`/`bsc`、`CT_501`/`solana`/`sol`、
  `4663`/`robinhood`、`99901`/`elysium` 都认），**认不出的链直接跳过**，不发空请求。
- 只有 `ok` 且真有正文才算命中；`no-narrative` / `auth` / `error` 一律继续兜底，
  不会把「还在生成」误当成「这个币没叙事」。
- 去重键 `exchange_ai_address_key()`：**EVM 折叠大小写，base58 绝不折叠**。
- 想彻底切断币安：`EXCHANGE_AI_NARRATIVE_LEGACY_FALLBACK=0`。代价是 GIGA X 没覆盖
  的币（新币还没生成、只有 ticker 的中心化行情行）会直接显示「暂无叙事」。

---

## 六、常见问题

**`桥接返回非 JSON（HTTP 200）`**
路由前缀写错，打到了静态文件服务上（拿到的是 `index.html`）。检查脚本里的桥接地址与
服务端路由是否一致。

**叙事和卡片上的币对不上**
按 `Alt+G` 看 `解析结果 … 来源 xxx`。若来源是 `popup-multi`，说明这个浮层 DOM 里有多个地址，
可以把那一行和 DOM 片段发出来调选择器；若是 `pointer` 且鼠标位置比较特殊，把鼠标停在卡片上再打开。

**`Invalid app client ID`**
`privyClientId` 填成了 JWT 里的 `app_client_id`（内部 id）。要填 `client-XXXX` 形式的
`androidClientId`。

**`Invalid nativeAppID` / `Origin not allowed`**
`nativeAppId` 没填或不是包名；`Origin` 需与服务端保持一致（脚本走本机 HTTP，一般无此问题）。

**`{"code":-1,"msg":"Invalid token"}`**
access token 不对（常见于误用了 `privy_access_token` / `pat`）。必须用 `aud` 等于 App ID 的那个
access token；桥接里已做校验，遇到 pat 会直接报错而不是静默返回错内容。

**过了 30 天突然全挂**
Privy 的 refresh token 默认 30 天到期。`/api/gigax/health` 里 `refreshTokenAgeDays ≥ 25`
时保活线程会每天提示一次。这时重登一次 App、再跑一遍第 2 步即可。

**模拟器上的时间被我改过？**
`--force-http1`/抓包时可能会调时钟。恢复：`settings put global auto_time 1` 再 `date` 对一次。

---

## 七、安全与合规

- `bridge/.state/captured.json` 里是**你本人账号的凭据**，等于账号密码，**不要提交、不要外发**；
  本包不包含它，示例见 `captured.example.json`。
- 桥接服务默认只监听 `127.0.0.1`。确实要给局域网设备用再加 `--host 0.0.0.0`，
  并且清楚这意味着同网段任何人都能拿你的 token 调接口。
- 这套东西依赖对 GIGA X / GMGN 客户端的逆向与自动化调用，**可能违反对方服务条款**，
  也可能随时因对方改接口而失效；自用、自担风险，别用于批量抓取或对外提供服务。

---

## 八、版本

- userscript 1.7.0 / bridge 1.1.0
- **1.7.0：改用 GMGN 自己的 data 属性取址 —— 这是「币和叙事对不上」这个老问题的终结版。**
  前面十几版一直在**猜** DOM（看截图、看日志、看接口返回），这一版第一次用
  `chrome-devtools-mcp` 把真实战壕页加载起来读了 DOM，结论是：
  ① 战壕卡片里代币链接是 **0/1/2 个**，币名是**纯文本**不是链接 —— 靠链接找币在战壕区天然失败；
  ② GMGN 其实把地址写在属性里：`data-trenches-token-address` + `data-trenches-token-chain`
  （一卡一个，30/30 唯一）、列表行 `data-row-key="bsc:0x…"`；
  ③ 同名不同币真实存在（`PENGB`×2、`NVIDIASI`×2 各自不同 CA），所以「靠 symbol 认币」不可靠。
  于是取址优先级新增**第 0 位 `data`**，标色也直接标在属性所在节点（= 卡片本体，326×144 / 260×44）。
  另加**回收键观察**：虚拟列表把同一个节点复用给另一个币时（`data-recycler-key` 变），立刻重刷标色。
  实测：战壕区 60/60 采样点全中、**0 认错**；左侧 34/44 命中、0 认错（未命中的点全被喊单浮窗盖住）。
- 1.6.0：**修「红薯小猫弹出 PIKA」**（换币识别）与**「标记一会又没了」**（重刷请求被丢）。
  ① 新增**浮层身份识别**（`why: identity`）：浮层头部（名字 / @handle，剔除我们写入的节点、
  剥掉所有数字）与页面上各张卡片的文字比**公共前缀**，前缀最长且唯一的那张卡片就是它讲的币。
  这是「GMGN 自己写的这个浮层是谁」，比 hover 和网络嗅探都可靠，排在取址优先级第 2 位；
  同时用同一指纹做换币检测（`staleTarget`）—— 浮层头部一变就整块重来。
  ② `schedulePaint` 不再丢弃重刷请求：老写法「800ms 内再来一次就 return」会让那次重刷永远丢失，
  而 React 每次价格跳动都会换卡片节点、class 全没 —— 表现就是「刚刚还标着，一会又没了」。
  现在合并请求 + 400ms 地板 + 到点**强制执行**，并加了 3 秒保底重刷。
  ③ 版本号写进 `SCRIPT_VERSION`，诊断面板标题和叙事徽标 `title` 都会显示，便于确认装的是哪一版。
- 1.5.9：**修「不同币弹出同一段叙事」与「战壕卡片不标色」**。
  ① 浮层容器是复用的 —— GMGN 换币时只改标题数字，**不重写那段正文**，我们塞进去的上一段
  叙事会一直留着（IDRENT、红薯小猫都弹 PIKA）。现在每轮都用 `staleTarget()` 校验
  「浮层现在讲的还是不是当初那个币」，换了就整块重来；
  ② 卡片里允许出现 **2 个**代币链接（`CARD_MAX_CAS`）—— 战壕卡片自身常带配对/相关币，
  老规则「出现第二个就停」在第一层就放弃，于是右边战壕一个都不标、左边列表却正常；
  ③ `isPainted` 认「透明底 + 有边框」的盒子，战壕卡片不会再只亮内层一小块；
  ④ 新增 `Alt+Shift+G` 页面内诊断面板（每个币：有没有取到叙事 / 命不命中关键词 /
  卡片找没找到、多大、有没有背景），出问题截图即可定位。
- 1.5.8：**修「代币和叙事对不上」**（卡片 Pussy / 叙事 hotdog）。三处根因一起改：
  ① 优先级重排为「浮窗自带地址 > hover 到的卡片 > 指针 > 浮窗多地址交叉 > 详情页 URL >
  叙事请求（必须能在页面上找到这个币）」，**详情页 URL 不再压过 hover 的卡片**；
  ② 新增 hover 锚点（hover 当时记下卡片 CA + 矩形 + symbol，事后用「指针还在卡片里 /
  浮窗文字含这个 symbol / 浮窗紧贴卡片」三判据认领），解决浮窗盖住鼠标后锚点丢失；
  ③ 反查卡片时**不许越过卡片边界**（出现第二个代币链接就停），并删掉「最近 8s 任意请求」兜底。
  另加并发防护：响应回来时浮窗已换币则丢弃该正文。`GIGA X 叙事` 徽标悬停可看地址与来源。
- 1.5.5~1.5.7：修「叙事和币对不上」的早期版本（详情页 URL 优先、网络嗅探 TTL 120s→30s）、
  降低主线程抢占（锚点索引 / 缓存 / idle 回调 / 预取与扫描解耦）
- 1.5.5：修「叙事和币对不上」（hotdog 详情页浮窗显示 COST 叙事）—— resolveTarget 改为
  详情页强制用页面 URL 的币、浮窗自带唯一地址优先，网络嗅探 TTL 120s→30s
- 1.5.4：修「列表整列染蓝」的误判（第二个币只按代币链接判、不再误杀钱包地址），
  详情页/当前正在看的币也标；标记持久化 TTL 2h→24h；大幅降低对主线程的抢占
  （深扫 1s→3s 且只扫叶子、轮询 800ms→1.5s、paint 防抖 400→800ms），修 K 线图卡顿
- 1.5.3：修「列表整列染蓝」—— 卡片定位加「第二个币就停 + 尺寸上限」两道硬边界
- 1.5.2：标色换成 DeepSeek logo 那个蓝 `#4D6BFE`（比 sky-400 深、比宝蓝亮），
  战壕榜深色卡片上 30% 就够醒目；色值抽成 `HOT_RGB`/`HOT_RING` 两个常量，以后调色只改一行
- 1.5.1：底色改亮蓝 sky-400 + 2px 实心描边（12%/22% 在深色卡片上看不见）、
  卡片定位改为优先取「有背景」的祖先（战壕榜卡片原来刷在透明内层上）
- 1.5.0：批量接口 `/api/gigax/narratives`（一屏一条请求、服务端并发、30 分钟进程缓存）、
  自动预取当前屏（不用 hover）、标记结果持久化、详情页页头不再标、底色默认 22%
- 1.4.0：叙事关键词命中时把对应卡片刷浅蓝底（机会标记），菜单可关/可放宽
- 1.3.0：GMGN 地址页形状（`/<chain>/token/<CA>`）解析、Solana 地址不再小写化、
  hover 预热 + DOM 观察消除「先原生后替换」的闪烁、GIGA X 无叙事时保留原文
- 适配时间：2026-11（GIGA X 1.0.4 / `@privy-io/expo` 0.74.x）
